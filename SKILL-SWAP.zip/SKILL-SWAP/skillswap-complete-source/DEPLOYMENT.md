# Deployment Guide

## Local Development
1. Copy `.env.example` to `.env` and fill in your values
2. Run `npm install`
3. Run `npm run db:push`
4. Run `npm run dev`

## Production Deployment

### On Replit
1. Import this project to a new Repl
2. Set up environment variables in the Secrets tab
3. Run `npm run db:push`
4. The project will automatically start

### On Other Platforms
1. Set up a PostgreSQL database
2. Configure environment variables
3. Run `npm run build`
4. Start with `npm run start`

## Database Setup
The project uses Drizzle ORM with PostgreSQL:
- Schema is defined in `shared/schema.ts`
- Run `npm run db:push` to create tables
- Use `npm run db:studio` to view data

## Environment Variables
All required environment variables are documented in `.env.example`
