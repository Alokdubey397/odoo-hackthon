# SkillSwap Platform - Complete Source Code

## Overview
SkillSwap is a comprehensive skill exchange platform that connects people to trade skills and knowledge. Built with modern web technologies, it features user authentication, skill management, swap requests, reviews, and admin functionality.

## Features
- **User Authentication**: Secure login with Replit Auth (OpenID Connect)
- **Skill Management**: Add, edit, and categorize skills you offer or want
- **Discovery**: Find users with complementary skills
- **Swap Requests**: Send and manage skill exchange requests
- **Reviews**: Rate and review completed skill exchanges
- **Admin Panel**: Platform administration and user management
- **Responsive Design**: Works on all devices

## Tech Stack
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS
- **Backend**: Express.js, Node.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **UI Components**: shadcn/ui (Radix UI)
- **State Management**: TanStack Query

## Installation

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- Replit account (for authentication)

### Setup
1. Install dependencies:
   ```bash
   npm install
   ```

2. Set up environment variables:
   ```bash
   DATABASE_URL=your_postgresql_connection_string
   SESSION_SECRET=your_secure_session_secret
   REPLIT_DOMAINS=your_replit_domain
   REPL_ID=your_repl_id
   ```

3. Push database schema:
   ```bash
   npm run db:push
   ```

4. (Optional) Add sample data:
   ```bash
   npx tsx scripts/populate-indian-data.ts
   ```

5. Start the development server:
   ```bash
   npm run dev
   ```

## Project Structure
```
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utility functions
├── server/              # Express backend
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API routes
│   ├── db.ts           # Database configuration
│   └── storage.ts       # Data access layer
├── shared/              # Shared TypeScript types
│   └── schema.ts        # Database schema definitions
└── scripts/             # Utility scripts
```

## Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run db:push` - Push database schema
- `npm run db:studio` - Open database studio

## Sample Data
The platform includes sample Indian users and skills for demonstration:
- Users with authentic Indian names and locations
- Skills covering technology, arts, languages, and traditional knowledge
- Culturally relevant content and contexts

## Authentication
The platform uses Replit Auth for secure authentication:
- OpenID Connect integration
- Automatic user profile creation
- Session management with PostgreSQL
- Role-based access control

## API Endpoints
- `GET /api/auth/user` - Get current user
- `GET /api/skills` - Get user skills
- `POST /api/skills` - Create new skill
- `GET /api/discover/matches` - Find skill matches
- `POST /api/swaps` - Create swap request
- `GET /api/swaps` - Get user's swap requests
- `POST /api/reviews` - Create review

## Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License
This project is open source and available under the MIT License.

## Support
For questions or issues, please create an issue in the repository or contact the development team.

---

Generated on: 2025-07-12T08:52:19.563Z
Platform: SkillSwap v1.0.0
