import { db } from "../server/db";
import { users, skills } from "../shared/schema";

const sampleUsers = [
  {
    id: "user1",
    email: "priya.sharma@example.com",
    firstName: "Priya",
    lastName: "Sharma",
    profileImageUrl: "https://images.unsplash.com/photo-1494790108755-2616b332c2e9?w=200&h=200&fit=crop&crop=face",
    bio: "Full-stack developer from Mumbai with 5 years of experience in web development.",
    title: "Senior Software Engineer",
    location: "Mumbai, Maharashtra",
    isAdmin: false,
  },
  {
    id: "user2",
    email: "raj.patel@example.com",
    firstName: "Raj",
    lastName: "Patel",
    profileImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face",
    bio: "Digital marketing expert specializing in social media and content strategy.",
    title: "Digital Marketing Manager",
    location: "Ahmedabad, Gujarat",
    isAdmin: false,
  },
  {
    id: "user3",
    email: "anita.singh@example.com",
    firstName: "Anita",
    lastName: "Singh",
    profileImageUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face",
    bio: "Yoga instructor and wellness coach with traditional Ayurvedic knowledge.",
    title: "Yoga & Wellness Coach",
    location: "Rishikesh, Uttarakhand",
    isAdmin: false,
  },
  {
    id: "user4",
    email: "vikram.reddy@example.com",
    firstName: "Vikram",
    lastName: "Reddy",
    profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
    bio: "Data scientist with expertise in machine learning and AI applications.",
    title: "Senior Data Scientist",
    location: "Bangalore, Karnataka",
    isAdmin: false,
  },
  {
    id: "user5",
    email: "kavya.nair@example.com",
    firstName: "Kavya",
    lastName: "Nair",
    profileImageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=face",
    bio: "Classical dancer specializing in Bharatanatyam and contemporary fusion.",
    title: "Dance Instructor",
    location: "Kochi, Kerala",
    isAdmin: false,
  },
  {
    id: "user6",
    email: "arjun.gupta@example.com",
    firstName: "Arjun",
    lastName: "Gupta",
    profileImageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face",
    bio: "Chef specializing in North Indian cuisine and street food.",
    title: "Executive Chef",
    location: "Delhi, NCR",
    isAdmin: false,
  },
  {
    id: "user7",
    email: "meera.joshi@example.com",
    firstName: "Meera",
    lastName: "Joshi",
    profileImageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=face",
    bio: "Graphic designer with expertise in branding and digital illustration.",
    title: "Creative Director",
    location: "Pune, Maharashtra",
    isAdmin: false,
  },
  {
    id: "user8",
    email: "rohit.kumar@example.com",
    firstName: "Rohit",
    lastName: "Kumar",
    profileImageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face",
    bio: "Financial advisor with CFA certification and stock market expertise.",
    title: "Senior Financial Advisor",
    location: "Kolkata, West Bengal",
    isAdmin: false,
  },
  {
    id: "admin1",
    email: "admin@skillswap.com",
    firstName: "Admin",
    lastName: "User",
    profileImageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=face",
    bio: "Platform administrator",
    title: "Platform Administrator",
    location: "India",
    isAdmin: true,
  },
];

const sampleSkills = [
  // Priya Sharma - Software Engineer
  { userId: "user1", name: "React.js", level: "Expert", type: "offered", category: "Technology", description: "Building scalable web applications with React and Redux" },
  { userId: "user1", name: "Node.js", level: "Expert", type: "offered", category: "Technology", description: "Backend development with Express.js and MongoDB" },
  { userId: "user1", name: "Hindi", level: "Beginner", type: "wanted", category: "Language", description: "Want to improve Hindi speaking skills" },
  { userId: "user1", name: "Photography", level: "Beginner", type: "wanted", category: "Arts", description: "Learning portrait and landscape photography" },

  // Raj Patel - Digital Marketing Manager
  { userId: "user2", name: "Digital Marketing", level: "Expert", type: "offered", category: "Business", description: "SEO, SEM, and social media marketing strategies" },
  { userId: "user2", name: "Gujarati", level: "Expert", type: "offered", category: "Language", description: "Native Gujarati speaker, can teach conversational skills" },
  { userId: "user2", name: "Python", level: "Intermediate", type: "wanted", category: "Technology", description: "Learning Python for data analysis and automation" },
  { userId: "user2", name: "Content Writing", level: "Intermediate", type: "wanted", category: "Writing", description: "Improving technical writing skills" },

  // Anita Singh - Yoga & Wellness Coach
  { userId: "user3", name: "Yoga", level: "Expert", type: "offered", category: "Health", description: "Hatha, Vinyasa, and restorative yoga practices" },
  { userId: "user3", name: "Meditation", level: "Expert", type: "offered", category: "Health", description: "Mindfulness and traditional meditation techniques" },
  { userId: "user3", name: "Ayurveda", level: "Advanced", type: "offered", category: "Health", description: "Traditional Ayurvedic lifestyle and nutrition guidance" },
  { userId: "user3", name: "Web Design", level: "Beginner", type: "wanted", category: "Technology", description: "Want to create a website for my wellness practice" },

  // Vikram Reddy - Data Scientist
  { userId: "user4", name: "Machine Learning", level: "Expert", type: "offered", category: "Technology", description: "ML algorithms, deep learning, and model deployment" },
  { userId: "user4", name: "Python", level: "Expert", type: "offered", category: "Technology", description: "Data science, analysis, and automation with Python" },
  { userId: "user4", name: "Telugu", level: "Expert", type: "offered", category: "Language", description: "Native Telugu speaker, can teach writing and literature" },
  { userId: "user4", name: "Photography", level: "Intermediate", type: "wanted", category: "Arts", description: "Learning landscape and street photography" },

  // Kavya Nair - Dance Instructor
  { userId: "user5", name: "Bharatanatyam", level: "Expert", type: "offered", category: "Arts", description: "Classical Indian dance with 15+ years of training" },
  { userId: "user5", name: "Contemporary Dance", level: "Advanced", type: "offered", category: "Arts", description: "Modern dance and choreography" },
  { userId: "user5", name: "Malayalam", level: "Expert", type: "offered", category: "Language", description: "Native Malayalam speaker with literature knowledge" },
  { userId: "user5", name: "Video Editing", level: "Beginner", type: "wanted", category: "Technology", description: "Want to create dance tutorial videos" },

  // Arjun Gupta - Executive Chef
  { userId: "user6", name: "North Indian Cooking", level: "Expert", type: "offered", category: "Cooking", description: "Traditional recipes and modern techniques" },
  { userId: "user6", name: "Street Food", level: "Expert", type: "offered", category: "Cooking", description: "Authentic Indian street food preparation" },
  { userId: "user6", name: "Food Photography", level: "Intermediate", type: "offered", category: "Arts", description: "Styling and photographing food for social media" },
  { userId: "user6", name: "Business Management", level: "Intermediate", type: "wanted", category: "Business", description: "Want to learn restaurant management skills" },

  // Meera Joshi - Creative Director
  { userId: "user7", name: "Graphic Design", level: "Expert", type: "offered", category: "Design", description: "Branding, logos, and digital illustration" },
  { userId: "user7", name: "Adobe Creative Suite", level: "Expert", type: "offered", category: "Technology", description: "Photoshop, Illustrator, InDesign, and After Effects" },
  { userId: "user7", name: "UI/UX Design", level: "Advanced", type: "offered", category: "Design", description: "User interface and experience design" },
  { userId: "user7", name: "Marathi", level: "Beginner", type: "wanted", category: "Language", description: "Want to learn Marathi for better client communication" },

  // Rohit Kumar - Financial Advisor
  { userId: "user8", name: "Financial Planning", level: "Expert", type: "offered", category: "Finance", description: "Personal finance, investment strategies, and retirement planning" },
  { userId: "user8", name: "Stock Market Analysis", level: "Expert", type: "offered", category: "Finance", description: "Technical and fundamental analysis of stocks" },
  { userId: "user8", name: "Bengali", level: "Expert", type: "offered", category: "Language", description: "Native Bengali speaker, can teach literature and poetry" },
  { userId: "user8", name: "Excel", level: "Intermediate", type: "wanted", category: "Technology", description: "Advanced Excel functions for financial modeling" },
];

export async function populateIndianData() {
  try {
    console.log("Populating database with Indian sample data...");
    
    // Insert users
    for (const user of sampleUsers) {
      await db.insert(users).values(user).onConflictDoNothing();
    }
    console.log("✓ Users inserted successfully");

    // Insert skills
    for (const skill of sampleSkills) {
      await db.insert(skills).values(skill).onConflictDoNothing();
    }
    console.log("✓ Skills inserted successfully");

    console.log("Database populated with Indian sample data!");
  } catch (error) {
    console.error("Error populating database:", error);
  }
}

// Run the script if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  populateIndianData().then(() => process.exit(0));
}