import * as fs from 'fs';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const EXCLUDED_DIRS = [
  'node_modules',
  '.git',
  'dist',
  '.replit',
  'attached_assets',
  '.vscode',
  'coverage',
  'build'
];

const EXCLUDED_FILES = [
  '.env',
  '.env.local',
  '.env.production',
  '.env.development',
  'package-lock.json',
  'yarn.lock',
  'pnpm-lock.yaml',
  '.DS_Store',
  'Thumbs.db',
  '.gitignore'
];

interface FileInfo {
  path: string;
  content: string;
  isDirectory: boolean;
}

async function getAllFiles(dir: string, basePath: string = ''): Promise<FileInfo[]> {
  const files: FileInfo[] = [];
  const items = await fs.promises.readdir(dir, { withFileTypes: true });

  for (const item of items) {
    const fullPath = path.join(dir, item.name);
    const relativePath = path.join(basePath, item.name);

    if (item.isDirectory()) {
      if (EXCLUDED_DIRS.includes(item.name)) {
        continue;
      }
      
      files.push({
        path: relativePath,
        content: '',
        isDirectory: true
      });

      const subFiles = await getAllFiles(fullPath, relativePath);
      files.push(...subFiles);
    } else {
      if (EXCLUDED_FILES.includes(item.name)) {
        continue;
      }

      try {
        const content = await fs.promises.readFile(fullPath, 'utf-8');
        files.push({
          path: relativePath,
          content,
          isDirectory: false
        });
      } catch (error) {
        console.warn(`Could not read file ${fullPath}: ${error}`);
      }
    }
  }

  return files;
}

async function generateReadme(): Promise<string> {
  return `# SkillSwap Platform - Complete Source Code

## Overview
SkillSwap is a comprehensive skill exchange platform that connects people to trade skills and knowledge. Built with modern web technologies, it features user authentication, skill management, swap requests, reviews, and admin functionality.

## Features
- **User Authentication**: Secure login with Replit Auth (OpenID Connect)
- **Skill Management**: Add, edit, and categorize skills you offer or want
- **Discovery**: Find users with complementary skills
- **Swap Requests**: Send and manage skill exchange requests
- **Reviews**: Rate and review completed skill exchanges
- **Admin Panel**: Platform administration and user management
- **Responsive Design**: Works on all devices

## Tech Stack
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS
- **Backend**: Express.js, Node.js, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **UI Components**: shadcn/ui (Radix UI)
- **State Management**: TanStack Query

## Installation

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- Replit account (for authentication)

### Setup
1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

2. Set up environment variables:
   \`\`\`bash
   DATABASE_URL=your_postgresql_connection_string
   SESSION_SECRET=your_secure_session_secret
   REPLIT_DOMAINS=your_replit_domain
   REPL_ID=your_repl_id
   \`\`\`

3. Push database schema:
   \`\`\`bash
   npm run db:push
   \`\`\`

4. (Optional) Add sample data:
   \`\`\`bash
   npx tsx scripts/populate-indian-data.ts
   \`\`\`

5. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

## Project Structure
\`\`\`
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utility functions
├── server/              # Express backend
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API routes
│   ├── db.ts           # Database configuration
│   └── storage.ts       # Data access layer
├── shared/              # Shared TypeScript types
│   └── schema.ts        # Database schema definitions
└── scripts/             # Utility scripts
\`\`\`

## Available Scripts
- \`npm run dev\` - Start development server
- \`npm run build\` - Build for production
- \`npm run start\` - Start production server
- \`npm run db:push\` - Push database schema
- \`npm run db:studio\` - Open database studio

## Sample Data
The platform includes sample Indian users and skills for demonstration:
- Users with authentic Indian names and locations
- Skills covering technology, arts, languages, and traditional knowledge
- Culturally relevant content and contexts

## Authentication
The platform uses Replit Auth for secure authentication:
- OpenID Connect integration
- Automatic user profile creation
- Session management with PostgreSQL
- Role-based access control

## API Endpoints
- \`GET /api/auth/user\` - Get current user
- \`GET /api/skills\` - Get user skills
- \`POST /api/skills\` - Create new skill
- \`GET /api/discover/matches\` - Find skill matches
- \`POST /api/swaps\` - Create swap request
- \`GET /api/swaps\` - Get user's swap requests
- \`POST /api/reviews\` - Create review

## Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License
This project is open source and available under the MIT License.

## Support
For questions or issues, please create an issue in the repository or contact the development team.

---

Generated on: ${new Date().toISOString()}
Platform: SkillSwap v1.0.0
`;
}

async function createDownloadPackage(): Promise<void> {
  console.log('🚀 Starting download package generation...');
  
  const outputDir = './skillswap-complete-source';
  const zipFile = './skillswap-complete-source.zip';
  
  try {
    // Remove existing output directory if it exists
    if (fs.existsSync(outputDir)) {
      await fs.promises.rm(outputDir, { recursive: true, force: true });
    }
    
    // Create output directory
    await fs.promises.mkdir(outputDir, { recursive: true });
    
    // Get all files from the project
    console.log('📁 Collecting project files...');
    const files = await getAllFiles('./');
    
    // Create directory structure and copy files
    console.log('📝 Creating file structure...');
    for (const file of files) {
      const outputPath = path.join(outputDir, file.path);
      
      if (file.isDirectory) {
        await fs.promises.mkdir(outputPath, { recursive: true });
      } else {
        const outputFileDir = path.dirname(outputPath);
        await fs.promises.mkdir(outputFileDir, { recursive: true });
        await fs.promises.writeFile(outputPath, file.content);
      }
    }
    
    // Generate README
    console.log('📄 Generating README...');
    const readme = await generateReadme();
    await fs.promises.writeFile(path.join(outputDir, 'README.md'), readme);
    
    // Create a sample .env file
    console.log('⚙️  Creating sample environment file...');
    const sampleEnv = `# SkillSwap Environment Variables
# Copy this file to .env and fill in your actual values

# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/skillswap
PGHOST=localhost
PGPORT=5432
PGUSER=your_username
PGPASSWORD=your_password
PGDATABASE=skillswap

# Authentication (Replit Auth)
SESSION_SECRET=your_super_secure_session_secret_here
REPLIT_DOMAINS=your-repl-domain.replit.dev
REPL_ID=your_repl_id
ISSUER_URL=https://replit.com/oidc

# Development
NODE_ENV=development
PORT=5000
`;
    
    await fs.promises.writeFile(path.join(outputDir, '.env.example'), sampleEnv);
    
    // Create deployment guide
    console.log('🚀 Creating deployment guide...');
    const deploymentGuide = `# Deployment Guide

## Local Development
1. Copy \`.env.example\` to \`.env\` and fill in your values
2. Run \`npm install\`
3. Run \`npm run db:push\`
4. Run \`npm run dev\`

## Production Deployment

### On Replit
1. Import this project to a new Repl
2. Set up environment variables in the Secrets tab
3. Run \`npm run db:push\`
4. The project will automatically start

### On Other Platforms
1. Set up a PostgreSQL database
2. Configure environment variables
3. Run \`npm run build\`
4. Start with \`npm run start\`

## Database Setup
The project uses Drizzle ORM with PostgreSQL:
- Schema is defined in \`shared/schema.ts\`
- Run \`npm run db:push\` to create tables
- Use \`npm run db:studio\` to view data

## Environment Variables
All required environment variables are documented in \`.env.example\`
`;
    
    await fs.promises.writeFile(path.join(outputDir, 'DEPLOYMENT.md'), deploymentGuide);
    
    console.log('✅ Download package created successfully!');
    console.log(`📦 Package location: ${path.resolve(outputDir)}`);
    console.log(`📄 Files included: ${files.length}`);
    
    // List key files
    console.log('\n📋 Key files included:');
    const keyFiles = files.filter(f => !f.isDirectory).slice(0, 10);
    keyFiles.forEach(file => {
      console.log(`   - ${file.path}`);
    });
    
    if (files.length > 10) {
      console.log(`   ... and ${files.length - 10} more files`);
    }
    
    console.log('\n🎉 Your complete SkillSwap source code is ready!');
    console.log(`📂 Open the folder: ${path.resolve(outputDir)}`);
    
  } catch (error) {
    console.error('❌ Error creating download package:', error);
    throw error;
  }
}

// Run the script
if (import.meta.url === `file://${process.argv[1]}`) {
  createDownloadPackage()
    .then(() => {
      console.log('\n✨ Package generation complete!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Failed to generate package:', error);
      process.exit(1);
    });
}

export { createDownloadPackage };