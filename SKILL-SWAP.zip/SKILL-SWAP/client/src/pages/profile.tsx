import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/layout/header";
import { User, Edit3, Plus, Trash2, Star, Award } from "lucide-react";

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  title: z.string().optional(),
  bio: z.string().optional(),
  location: z.string().optional(),
});

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);

  const form = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      title: user?.title || "",
      bio: user?.bio || "",
      location: user?.location || "",
    },
  });

  const { data: skills, isLoading: skillsLoading } = useQuery({
    queryKey: ["/api/skills"],
    retry: false,
  });

  const { data: reviews, isLoading: reviewsLoading } = useQuery({
    queryKey: ["/api/reviews", user?.id],
    enabled: !!user?.id,
    retry: false,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("PUT", "/api/users/me", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    updateProfileMutation.mutate(data);
  };

  const offeredSkills = skills?.filter((skill: any) => skill.type === "offered") || [];
  const wantedSkills = skills?.filter((skill: any) => skill.type === "wanted") || [];

  const averageRating = reviews?.reduce((acc: number, review: any) => acc + review.rating, 0) / (reviews?.length || 1) || 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Profile</h1>
          <p className="text-gray-600">Manage your profile and skills</p>
        </div>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center">
                    <User className="mr-2 h-5 w-5" />
                    Profile Information
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsEditing(!isEditing)}
                  >
                    <Edit3 className="mr-2 h-4 w-4" />
                    {isEditing ? "Cancel" : "Edit"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={user?.profileImageUrl} alt={user?.firstName} className="object-cover" />
                      <AvatarFallback className="text-xl">
                        {user?.firstName?.[0]}{user?.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  
                  <div className="flex-1">
                    {isEditing ? (
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="firstName">First Name</Label>
                            <Input {...form.register("firstName")} />
                            {form.formState.errors.firstName && (
                              <p className="text-sm text-red-500 mt-1">
                                {form.formState.errors.firstName.message}
                              </p>
                            )}
                          </div>
                          <div>
                            <Label htmlFor="lastName">Last Name</Label>
                            <Input {...form.register("lastName")} />
                            {form.formState.errors.lastName && (
                              <p className="text-sm text-red-500 mt-1">
                                {form.formState.errors.lastName.message}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="title">Title</Label>
                          <Input {...form.register("title")} placeholder="e.g., Software Developer" />
                        </div>
                        
                        <div>
                          <Label htmlFor="bio">Bio</Label>
                          <Textarea {...form.register("bio")} placeholder="Tell us about yourself..." />
                        </div>
                        
                        <div>
                          <Label htmlFor="location">Location</Label>
                          <Input {...form.register("location")} placeholder="e.g., San Francisco, CA" />
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button type="submit" disabled={updateProfileMutation.isPending}>
                            {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                          </Button>
                          <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                            Cancel
                          </Button>
                        </div>
                      </form>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <h2 className="text-2xl font-bold">
                            {user?.firstName} {user?.lastName}
                          </h2>
                          <p className="text-gray-600">{user?.title || "Skill Swapper"}</p>
                          <p className="text-gray-500">{user?.location}</p>
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            {Array.from({ length: 5 }, (_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < Math.floor(averageRating) ? "text-yellow-400 fill-current" : "text-gray-300"
                                }`}
                              />
                            ))}
                            <span className="ml-2 text-sm text-gray-600">
                              {averageRating.toFixed(1)} ({reviews?.length || 0} reviews)
                            </span>
                          </div>
                        </div>
                        
                        {user?.bio && (
                          <div>
                            <h3 className="font-semibold mb-2">About</h3>
                            <p className="text-gray-700">{user.bio}</p>
                          </div>
                        )}
                        
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <p className="text-2xl font-bold text-primary">{offeredSkills.length}</p>
                            <p className="text-sm text-gray-600">Skills Offered</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-secondary">{wantedSkills.length}</p>
                            <p className="text-sm text-gray-600">Skills Wanted</p>
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-green-600">0</p>
                            <p className="text-sm text-gray-600">Completed Swaps</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="skills">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center">
                      <Award className="mr-2 h-5 w-5 text-primary" />
                      Skills I Offer
                    </CardTitle>
                    <Button size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Skill
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {skillsLoading ? (
                    <div className="text-center py-4">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                    </div>
                  ) : offeredSkills.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Award className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                      <p>No skills offered yet</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {offeredSkills.map((skill: any) => (
                        <div key={skill.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{skill.name}</h4>
                            <p className="text-sm text-gray-600">{skill.level} • {skill.category}</p>
                            {skill.description && (
                              <p className="text-sm text-gray-500 mt-1">{skill.description}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant="secondary">{skill.level}</Badge>
                            <Button size="sm" variant="ghost">
                              <Edit3 className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" className="text-red-600">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center">
                      <Award className="mr-2 h-5 w-5 text-secondary" />
                      Skills I Want
                    </CardTitle>
                    <Button size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Skill
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {wantedSkills.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Award className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                      <p>No skills wanted yet</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {wantedSkills.map((skill: any) => (
                        <div key={skill.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{skill.name}</h4>
                            <p className="text-sm text-gray-600">{skill.level} • {skill.category}</p>
                            {skill.description && (
                              <p className="text-sm text-gray-500 mt-1">{skill.description}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant="secondary">{skill.level}</Badge>
                            <Button size="sm" variant="ghost">
                              <Edit3 className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" className="text-red-600">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reviews">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="mr-2 h-5 w-5 text-yellow-500" />
                  Reviews & Ratings
                </CardTitle>
              </CardHeader>
              <CardContent>
                {reviewsLoading ? (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  </div>
                ) : reviews?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Star className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No reviews yet</p>
                    <p className="text-sm">Complete some skill swaps to receive reviews</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="text-2xl font-bold">{averageRating.toFixed(1)}</p>
                        <div className="flex items-center">
                          {Array.from({ length: 5 }, (_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < Math.floor(averageRating) ? "text-yellow-400 fill-current" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <p className="text-sm text-gray-600">{reviews.length} reviews</p>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      {reviews.map((review: any) => (
                        <div key={review.id} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-3">
                                <AvatarImage src="" alt="Reviewer" />
                                <AvatarFallback>R</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="flex items-center">
                                  {Array.from({ length: 5 }, (_, i) => (
                                    <Star
                                      key={i}
                                      className={`h-3 w-3 ${
                                        i < review.rating ? "text-yellow-400 fill-current" : "text-gray-300"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <p className="text-sm text-gray-600">
                                  {new Date(review.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                          </div>
                          {review.comment && (
                            <p className="mt-2 text-gray-700">{review.comment}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Account Actions</h3>
                    <div className="space-y-2">
                      <Button variant="outline" onClick={() => window.location.href = '/api/logout'}>
                        Sign Out
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
