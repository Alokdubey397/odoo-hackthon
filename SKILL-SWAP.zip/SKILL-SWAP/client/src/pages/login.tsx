import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LogIn, Users, ArrowRight } from "lucide-react";

export default function Login() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
              <Users className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
            Welcome to SkillSwap
          </h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            Connect with others and exchange skills
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-center">Sign In</CardTitle>
            <CardDescription className="text-center">
              Join our community of skill exchangers
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                <h3 className="font-semibold text-sm mb-2">What you can do:</h3>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Share your skills and expertise</li>
                  <li>• Discover people with skills you want to learn</li>
                  <li>• Exchange knowledge through skill swaps</li>
                  <li>• Build your profile and get reviews</li>
                </ul>
              </div>

              <Button 
                onClick={handleLogin}
                className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90"
                size="lg"
              >
                <LogIn className="w-4 h-4" />
                Sign in with Replit
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>

            <div className="text-center">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                By signing in, you agree to our terms of service and privacy policy
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            New to SkillSwap? Your account will be created automatically when you sign in.
          </p>
        </div>
      </div>
    </div>
  );
}