import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download as DownloadIcon, Code, FileText, Settings, Database } from "lucide-react";

export default function Download() {
  const handleDownload = () => {
    // Create a link to download the tar.gz file
    const link = document.createElement('a');
    link.href = '/skillswap-complete-source.tar.gz';
    link.download = 'skillswap-complete-source.tar.gz';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Download SkillSwap Source Code
          </h1>
          <p className="text-gray-600 text-lg">
            Complete source code with all features, documentation, and setup instructions
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DownloadIcon className="w-5 h-5" />
              Complete Source Package
            </CardTitle>
            <CardDescription>
              Download the full SkillSwap platform source code with all components
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Code className="w-4 h-4" />
                    Frontend & Backend
                  </h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• React + TypeScript frontend</li>
                    <li>• Express.js + Node.js backend</li>
                    <li>• Complete component library</li>
                    <li>• API routes and middleware</li>
                  </ul>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    Database & Auth
                  </h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• PostgreSQL schema</li>
                    <li>• Drizzle ORM setup</li>
                    <li>• Replit Auth integration</li>
                    <li>• Sample Indian data</li>
                  </ul>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Documentation Included
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Complete README with setup instructions</li>
                  <li>• Deployment guide for various platforms</li>
                  <li>• Environment configuration examples</li>
                  <li>• API documentation</li>
                </ul>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Ready to Deploy
                </h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Pre-configured build scripts</li>
                  <li>• Sample environment files</li>
                  <li>• Database migration scripts</li>
                  <li>• Production-ready configuration</li>
                </ul>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">Package Size: ~2MB</p>
                    <p className="text-sm text-gray-600">Includes 145+ files</p>
                  </div>
                  <Button 
                    onClick={handleDownload}
                    size="lg"
                    className="bg-primary hover:bg-primary/90"
                  >
                    <DownloadIcon className="w-4 h-4 mr-2" />
                    Download Source Code
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Setup Guide</CardTitle>
            <CardDescription>
              Get started with your SkillSwap platform in minutes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">1. Extract and Install</h4>
                <code className="text-sm bg-white p-2 rounded block">
                  tar -xzf skillswap-complete-source.tar.gz<br/>
                  cd skillswap-complete-source<br/>
                  npm install
                </code>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">2. Configure Environment</h4>
                <code className="text-sm bg-white p-2 rounded block">
                  cp .env.example .env<br/>
                  # Edit .env with your database and auth settings
                </code>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">3. Setup Database</h4>
                <code className="text-sm bg-white p-2 rounded block">
                  npm run db:push<br/>
                  npx tsx scripts/populate-indian-data.ts
                </code>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">4. Start Development</h4>
                <code className="text-sm bg-white p-2 rounded block">
                  npm run dev
                </code>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}