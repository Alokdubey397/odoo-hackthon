import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/layout/header";
import { Plus, Clock, Gift, Search, Star, Users, BookOpen, TrendingUp } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  const { data: skills, isLoading: skillsLoading } = useQuery({
    queryKey: ["/api/skills"],
    enabled: !!user,
    retry: false,
  });

  const { data: pendingSwaps, isLoading: swapsLoading } = useQuery({
    queryKey: ["/api/swaps/pending"],
    enabled: !!user,
    retry: false,
  });

  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ["/api/discover/matches"],
    enabled: !!user,
    retry: false,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const offeredSkills = skills?.filter((skill: any) => skill.type === "offered") || [];
  const wantedSkills = skills?.filter((skill: any) => skill.type === "wanted") || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="text-center">
                  <Avatar className="h-20 w-20 mx-auto mb-4">
                    <AvatarImage src={user.profileImageUrl} alt={user.firstName} className="object-cover" />
                    <AvatarFallback>
                      {user.firstName?.[0]}{user.lastName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {user.firstName} {user.lastName}
                  </h3>
                  <p className="text-gray-600">{user.title || "Skill Swapper"}</p>
                  <div className="flex justify-center mt-2">
                    <div className="flex items-center">
                      {Array.from({ length: 5 }, (_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                      <span className="ml-2 text-sm text-gray-600">4.8 (24 reviews)</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Skills Offered</span>
                    <span className="font-semibold text-primary">{offeredSkills.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Skills Wanted</span>
                    <span className="font-semibold text-secondary">{wantedSkills.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Pending Swaps</span>
                    <span className="font-semibold text-accent">{pendingSwaps?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Completed</span>
                    <span className="font-semibold text-green-600">0</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            
            {/* Welcome Section */}
            <Card className="bg-gradient-to-r from-primary to-blue-600 text-white mb-6">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-2">
                  Welcome back, {user.firstName}!
                </h2>
                <p className="opacity-90 mb-4">
                  Ready to discover new skills and share your expertise?
                </p>
                <Link href="/discover">
                  <Button variant="secondary" className="text-primary">
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Skill
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Pending Swap Requests */}
            <Card className="mb-6">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center">
                    <Clock className="mr-2 h-5 w-5 text-accent" />
                    Pending Swap Requests
                  </CardTitle>
                  <span className="text-sm text-gray-600">
                    {pendingSwaps?.length || 0} pending
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                {swapsLoading ? (
                  <div className="space-y-4">
                    {[1, 2].map((i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-48 mb-2" />
                          <Skeleton className="h-3 w-32" />
                        </div>
                        <div className="flex space-x-2">
                          <Skeleton className="h-8 w-16" />
                          <Skeleton className="h-8 w-16" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : pendingSwaps?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Clock className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No pending swap requests</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingSwaps?.map((swap: any) => (
                      <Card key={swap.id} className="card-hover">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarImage src="" alt="Requester" />
                                <AvatarFallback>R</AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-medium text-gray-900">Swap Request</h4>
                                <p className="text-sm text-gray-600">
                                  Someone wants to trade skills with you
                                </p>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="default">
                                Accept
                              </Button>
                              <Button size="sm" variant="destructive">
                                Decline
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* My Skills Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              
              {/* Skills I Offer */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center">
                      <Gift className="mr-2 h-5 w-5 text-primary" />
                      Skills I Offer
                    </CardTitle>
                    <Button variant="ghost" size="sm" className="text-primary">
                      <Plus className="mr-1 h-4 w-4" />
                      Add
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {skillsLoading ? (
                    <div className="space-y-2">
                      {[1, 2, 3, 4].map((i) => (
                        <Skeleton key={i} className="h-8 w-24 rounded-full" />
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {offeredSkills.map((skill: any) => (
                        <Badge
                          key={skill.id}
                          variant="secondary"
                          className="skill-tag bg-blue-50 text-primary hover:bg-blue-100 cursor-pointer mr-2 mb-2"
                        >
                          {skill.name}
                          <span className="ml-2 text-xs opacity-60">{skill.level}</span>
                        </Badge>
                      ))}
                      {offeredSkills.length === 0 && (
                        <p className="text-gray-500 text-sm">No skills offered yet</p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Skills I Want */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="flex items-center">
                      <Search className="mr-2 h-5 w-5 text-secondary" />
                      Skills I Want
                    </CardTitle>
                    <Button variant="ghost" size="sm" className="text-secondary">
                      <Plus className="mr-1 h-4 w-4" />
                      Add
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {skillsLoading ? (
                    <div className="space-y-2">
                      {[1, 2, 3].map((i) => (
                        <Skeleton key={i} className="h-8 w-24 rounded-full" />
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {wantedSkills.map((skill: any) => (
                        <Badge
                          key={skill.id}
                          variant="secondary"
                          className="skill-tag bg-green-50 text-secondary hover:bg-green-100 cursor-pointer mr-2 mb-2"
                        >
                          {skill.name}
                          <span className="ml-2 text-xs opacity-60">{skill.level}</span>
                        </Badge>
                      ))}
                      {wantedSkills.length === 0 && (
                        <p className="text-gray-500 text-sm">No skills wanted yet</p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Recommended Matches */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-accent" />
                  Recommended Matches
                </CardTitle>
              </CardHeader>
              <CardContent>
                {matchesLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[1, 2].map((i) => (
                      <Card key={i}>
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <Skeleton className="h-12 w-12 rounded-full mr-3" />
                            <div>
                              <Skeleton className="h-4 w-24 mb-2" />
                              <Skeleton className="h-3 w-32" />
                            </div>
                          </div>
                          <Skeleton className="h-3 w-48 mb-2" />
                          <Skeleton className="h-3 w-40 mb-3" />
                          <div className="flex space-x-2">
                            <Skeleton className="h-8 w-24" />
                            <Skeleton className="h-8 w-16" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : matches?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No matches found</p>
                    <p className="text-sm">Add some skills to find potential matches</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {matches?.slice(0, 4).map((match: any) => (
                      <Card key={match.id} className="card-hover">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <Avatar className="h-12 w-12 mr-3">
                              <AvatarImage src={match.profileImageUrl} alt={match.firstName} className="object-cover" />
                              <AvatarFallback>
                                {match.firstName?.[0]}{match.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="font-medium text-gray-900">
                                {match.firstName} {match.lastName}
                              </h4>
                              <p className="text-sm text-gray-600">{match.title || "Skill Swapper"}</p>
                              <div className="flex items-center mt-1">
                                {Array.from({ length: 5 }, (_, i) => (
                                  <Star key={i} className="h-3 w-3 text-yellow-400 fill-current" />
                                ))}
                                <span className="ml-1 text-xs text-gray-600">4.9</span>
                              </div>
                            </div>
                          </div>
                          <div className="mb-3">
                            <p className="text-sm text-gray-600">
                              <span className="text-green-500">→</span> Available for skill exchange
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Button size="sm" className="flex-1">
                              <Users className="mr-1 h-4 w-4" />
                              Request Swap
                            </Button>
                            <Button size="sm" variant="outline">
                              View
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
