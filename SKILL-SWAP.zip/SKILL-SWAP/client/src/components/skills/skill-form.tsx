import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Plus, X } from "lucide-react";

const skillFormSchema = z.object({
  name: z.string().min(1, "Skill name is required"),
  description: z.string().optional(),
  level: z.enum(["beginner", "intermediate", "advanced", "expert"], {
    required_error: "Please select a skill level",
  }),
  category: z.string().min(1, "Category is required"),
  type: z.enum(["offered", "wanted"], {
    required_error: "Please select skill type",
  }),
});

type SkillFormData = z.infer<typeof skillFormSchema>;

interface SkillFormProps {
  onClose: () => void;
  skill?: any;
}

export default function SkillForm({ onClose, skill }: SkillFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<SkillFormData>({
    resolver: zodResolver(skillFormSchema),
    defaultValues: {
      name: skill?.name || "",
      description: skill?.description || "",
      level: skill?.level || "beginner",
      category: skill?.category || "",
      type: skill?.type || "offered",
    },
  });

  const createSkillMutation = useMutation({
    mutationFn: async (data: SkillFormData) => {
      return await apiRequest("POST", "/api/skills", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Skill added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add skill",
        variant: "destructive",
      });
    },
  });

  const updateSkillMutation = useMutation({
    mutationFn: async (data: SkillFormData) => {
      return await apiRequest("PUT", `/api/skills/${skill.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Skill updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      onClose();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update skill",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: SkillFormData) => {
    setIsSubmitting(true);
    try {
      if (skill) {
        await updateSkillMutation.mutateAsync(data);
      } else {
        await createSkillMutation.mutateAsync(data);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const categories = [
    "Technology",
    "Design",
    "Marketing",
    "Business",
    "Language",
    "Music",
    "Art",
    "Photography",
    "Writing",
    "Cooking",
    "Fitness",
    "Other",
  ];

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>{skill ? "Edit Skill" : "Add New Skill"}</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name">Skill Name</Label>
            <Input
              id="name"
              {...form.register("name")}
              placeholder="e.g., React.js, Photography, Spanish"
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.name.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="category">Category</Label>
            <Select
              value={form.watch("category")}
              onValueChange={(value) => form.setValue("category", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.category && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.category.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="level">Skill Level</Label>
            <Select
              value={form.watch("level")}
              onValueChange={(value) => form.setValue("level", value as any)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select skill level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
                <SelectItem value="expert">Expert</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.level && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.level.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="type">Skill Type</Label>
            <Select
              value={form.watch("type")}
              onValueChange={(value) => form.setValue("type", value as any)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select skill type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="offered">I can teach this</SelectItem>
                <SelectItem value="wanted">I want to learn this</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.type && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.type.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              {...form.register("description")}
              placeholder="Describe your experience with this skill..."
              rows={3}
            />
          </div>

          <div className="flex space-x-2">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  {skill ? "Updating..." : "Adding..."}
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  {skill ? "Update Skill" : "Add Skill"}
                </>
              )}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
