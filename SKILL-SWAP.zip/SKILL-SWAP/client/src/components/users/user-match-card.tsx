import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Users, Eye, ArrowRight, ArrowLeft } from "lucide-react";
import SwapRequestModal from "@/components/swaps/swap-request-modal";

interface UserMatchCardProps {
  user: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
    title?: string;
    email?: string;
  };
  offeredSkills?: any[];
  wantedSkills?: any[];
  rating?: number;
  onViewProfile?: (userId: string) => void;
}

export default function UserMatchCard({ 
  user, 
  offeredSkills = [], 
  wantedSkills = [],
  rating = 4.9,
  onViewProfile 
}: UserMatchCardProps) {
  
  const handleViewProfile = () => {
    if (onViewProfile) {
      onViewProfile(user.id);
    }
  };

  const displayedOfferedSkills = offeredSkills.slice(0, 3);
  const displayedWantedSkills = wantedSkills.slice(0, 3);

  return (
    <Card className="card-hover transition-all duration-200 hover:shadow-xl">
      <CardContent className="p-4">
        <div className="flex items-center mb-3">
          <Avatar className="h-12 w-12 mr-3">
            <AvatarImage src={user.profileImageUrl} alt={user.firstName} className="object-cover" />
            <AvatarFallback>
              {user.firstName?.[0]}{user.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div>
            <h4 className="font-medium text-gray-900">
              {user.firstName} {user.lastName}
            </h4>
            <p className="text-sm text-gray-600">{user.title || "Skill Swapper"}</p>
            <div className="flex items-center mt-1">
              {Array.from({ length: 5 }, (_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${
                    i < Math.floor(rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                  }`}
                />
              ))}
              <span className="ml-1 text-xs text-gray-600">{rating.toFixed(1)}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2 mb-4">
          {displayedOfferedSkills.length > 0 && (
            <div className="flex items-center text-sm text-gray-600">
              <ArrowRight className="h-4 w-4 text-green-500 mr-1 flex-shrink-0" />
              <span className="font-medium text-secondary mr-2">Offers:</span>
              <div className="flex flex-wrap gap-1">
                {displayedOfferedSkills.map((skill: any, index: number) => (
                  <Badge key={skill.id} variant="secondary" className="text-xs">
                    {skill.name}
                  </Badge>
                ))}
                {offeredSkills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{offeredSkills.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}
          
          {displayedWantedSkills.length > 0 && (
            <div className="flex items-center text-sm text-gray-600">
              <ArrowLeft className="h-4 w-4 text-blue-500 mr-1 flex-shrink-0" />
              <span className="font-medium text-primary mr-2">Wants:</span>
              <div className="flex flex-wrap gap-1">
                {displayedWantedSkills.map((skill: any, index: number) => (
                  <Badge key={skill.id} variant="outline" className="text-xs">
                    {skill.name}
                  </Badge>
                ))}
                {wantedSkills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{wantedSkills.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex space-x-2">
          <SwapRequestModal recipientUser={user} recipientSkills={offeredSkills}>
            <Button size="sm" className="flex-1 bg-primary hover:bg-primary/90">
              <Users className="mr-1 h-4 w-4" />
              Request Swap
            </Button>
          </SwapRequestModal>
          
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleViewProfile}
            className="px-3"
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
