import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star } from "lucide-react";

export default function Sidebar() {
  const { user } = useAuth();

  const { data: skills } = useQuery({
    queryKey: ["/api/skills"],
    enabled: !!user,
    retry: false,
  });

  const { data: pendingSwaps } = useQuery({
    queryKey: ["/api/swaps/pending"],
    enabled: !!user,
    retry: false,
  });

  const offeredSkills = skills?.filter((skill: any) => skill.type === "offered") || [];
  const wantedSkills = skills?.filter((skill: any) => skill.type === "wanted") || [];

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <div className="text-center">
            <Avatar className="h-20 w-20 mx-auto mb-4">
              <AvatarImage src={user?.profileImageUrl} alt={user?.firstName} className="object-cover" />
              <AvatarFallback className="text-lg">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <h3 className="text-lg font-semibold text-gray-900">
              {user?.firstName} {user?.lastName}
            </h3>
            <p className="text-gray-600">{user?.title || "Skill Swapper"}</p>
            <div className="flex justify-center mt-2">
              <div className="flex items-center">
                {Array.from({ length: 5 }, (_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
                <span className="ml-2 text-sm text-gray-600">4.8 (24 reviews)</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Stats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Skills Offered</span>
              <span className="font-semibold text-primary">{offeredSkills.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Skills Wanted</span>
              <span className="font-semibold text-secondary">{wantedSkills.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Pending Swaps</span>
              <span className="font-semibold text-accent">{pendingSwaps?.length || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Completed</span>
              <span className="font-semibold text-green-600">0</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
