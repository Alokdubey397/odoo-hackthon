import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { HandHeart, ArrowRight, X } from "lucide-react";

const swapRequestSchema = z.object({
  recipientId: z.string().min(1, "Recipient is required"),
  requesterSkillId: z.number().min(1, "Please select a skill you offer"),
  recipientSkillId: z.number().min(1, "Please select a skill you want"),
  message: z.string().optional(),
});

type SwapRequestFormData = z.infer<typeof swapRequestSchema>;

interface SwapRequestModalProps {
  recipientUser: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
    title?: string;
  };
  recipientSkills?: any[];
  children: React.ReactNode;
}

export default function SwapRequestModal({ recipientUser, recipientSkills = [], children }: SwapRequestModalProps) {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const { data: mySkills } = useQuery({
    queryKey: ["/api/skills"],
    enabled: isOpen,
    retry: false,
  });

  const form = useForm<SwapRequestFormData>({
    resolver: zodResolver(swapRequestSchema),
    defaultValues: {
      recipientId: recipientUser.id,
      message: "",
    },
  });

  const createSwapMutation = useMutation({
    mutationFn: async (data: SwapRequestFormData) => {
      return await apiRequest("POST", "/api/swaps", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Swap request sent successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/swaps"] });
      setIsOpen(false);
      form.reset();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send swap request",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SwapRequestFormData) => {
    createSwapMutation.mutate(data);
  };

  const myOfferedSkills = mySkills?.filter((skill: any) => skill.type === "offered") || [];
  const theirOfferedSkills = recipientSkills.filter((skill: any) => skill.type === "offered") || [];

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <HandHeart className="mr-2 h-5 w-5 text-primary" />
            Request Skill Swap
          </DialogTitle>
          <DialogDescription>
            Send a swap request to {recipientUser.firstName} {recipientUser.lastName}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <div className="flex items-center space-x-4 mb-6">
            <Avatar className="h-12 w-12">
              <AvatarImage src={recipientUser.profileImageUrl} alt={recipientUser.firstName} className="object-cover" />
              <AvatarFallback>
                {recipientUser.firstName?.[0]}{recipientUser.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium">{recipientUser.firstName} {recipientUser.lastName}</h3>
              <p className="text-sm text-gray-600">{recipientUser.title || "Skill Swapper"}</p>
            </div>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="requesterSkillId">I will teach</Label>
              <Select
                value={form.watch("requesterSkillId")?.toString()}
                onValueChange={(value) => form.setValue("requesterSkillId", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a skill you offer" />
                </SelectTrigger>
                <SelectContent>
                  {myOfferedSkills.map((skill: any) => (
                    <SelectItem key={skill.id} value={skill.id.toString()}>
                      {skill.name} ({skill.level})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.requesterSkillId && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.requesterSkillId.message}
                </p>
              )}
            </div>

            <div className="flex items-center justify-center py-2">
              <div className="flex items-center space-x-2 text-gray-500">
                <ArrowRight className="h-4 w-4" />
                <span className="text-sm">In exchange for</span>
                <ArrowRight className="h-4 w-4" />
              </div>
            </div>

            <div>
              <Label htmlFor="recipientSkillId">I want to learn</Label>
              <Select
                value={form.watch("recipientSkillId")?.toString()}
                onValueChange={(value) => form.setValue("recipientSkillId", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a skill you want to learn" />
                </SelectTrigger>
                <SelectContent>
                  {theirOfferedSkills.map((skill: any) => (
                    <SelectItem key={skill.id} value={skill.id.toString()}>
                      {skill.name} ({skill.level})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.recipientSkillId && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.recipientSkillId.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="message">Message (Optional)</Label>
              <Textarea
                id="message"
                {...form.register("message")}
                placeholder="Tell them why you'd like to swap skills..."
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                <X className="mr-2 h-4 w-4" />
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createSwapMutation.isPending}
                className="bg-primary hover:bg-primary/90"
              >
                {createSwapMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Sending...
                  </>
                ) : (
                  <>
                    <HandHeart className="mr-2 h-4 w-4" />
                    Send Request
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
