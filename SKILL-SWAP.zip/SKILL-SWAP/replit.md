# SkillSwap Platform

## Overview

SkillSwap is a modern web application that connects people to exchange skills and knowledge. Users can offer their expertise in various areas while seeking to learn from others, creating a community-driven skill trading platform. The application features user authentication, skill management, swap requests, reviews, and an admin panel.

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Recent Changes

### January 12, 2025
- **Fixed critical SQL error**: Resolved PostgreSQL array operator issue in skill matching algorithm
- **Added login page**: Created dedicated login page with beautiful UI and cultural context
- **Implemented download functionality**: Generated complete source code package (145+ files, 2MB)
- **Added Indian sample data**: Populated database with authentic Indian users and skills
- **Fixed authentication issues**: Resolved Unauthorized errors and session management
- **Updated navigation**: Added download link to landing page
- **Resolved all major errors**: Application now fully functional with all core features working

### Current Status
✅ All core functionality operational
✅ Authentication system working
✅ Skill matching algorithm fixed
✅ Database operations stable
✅ Indian sample data loaded
✅ Download package available
✅ Responsive design implemented

## System Architecture

### Full-Stack Architecture
The application follows a modern monorepo structure with clear separation between frontend, backend, and shared components:

- **Frontend**: React with TypeScript, built with Vite
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state

### Project Structure
```
├── client/          # React frontend
├── server/          # Express backend  
├── shared/          # Shared TypeScript schemas
├── migrations/      # Database migrations
└── dist/           # Build output
```

## Key Components

### Frontend Architecture
- **React SPA**: Single-page application with client-side routing using wouter
- **Component System**: shadcn/ui components for consistent UI/UX
- **State Management**: TanStack Query for API state management
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **TypeScript**: Full type safety across the application

### Backend Architecture
- **Express Server**: RESTful API with middleware for logging and error handling
- **Authentication Middleware**: Replit Auth integration with session management
- **Database Layer**: Drizzle ORM with connection pooling via Neon serverless
- **Storage Interface**: Abstract storage interface for data operations

### Authentication System
- **OpenID Connect**: Integration with Replit's authentication system
- **Session Management**: PostgreSQL-backed sessions with connect-pg-simple
- **User Management**: Automatic user creation and profile management
- **Authorization**: Role-based access control with admin functionality

## Data Flow

### User Registration/Login
1. User initiates login through Replit Auth
2. OpenID Connect flow handles authentication
3. User profile is automatically created/updated in database
4. Session is established and stored in PostgreSQL

### Skill Management
1. Users create skills with categories, levels, and descriptions
2. Skills are classified as "offered" or "wanted"
3. Data is validated using Zod schemas
4. Skills are stored with user relationships in PostgreSQL

### Swap Requests
1. Users browse available skills and user profiles
2. Swap requests are created with skill mappings
3. Recipients can accept/reject requests
4. Status updates trigger notifications and UI updates

### Review System
1. Completed swaps enable review creation
2. Reviews include ratings and comments
3. Reviews are displayed on user profiles
4. Aggregate ratings contribute to user reputation

## External Dependencies

### Core Framework Dependencies
- **React 18**: Frontend framework with modern hooks
- **Express.js**: Backend web framework
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the stack

### Database & ORM
- **PostgreSQL**: Primary database via Neon serverless
- **Drizzle ORM**: Type-safe database operations
- **Drizzle Kit**: Schema management and migrations

### Authentication
- **Replit Auth**: OpenID Connect integration
- **Passport.js**: Authentication middleware
- **express-session**: Session management

### UI/UX Libraries
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Headless UI components
- **shadcn/ui**: Pre-built component library
- **Lucide React**: Icon library

### State Management
- **TanStack Query**: Server state management
- **React Hook Form**: Form handling and validation
- **Zod**: Schema validation

## Deployment Strategy

### Development Environment
- **Replit Integration**: Optimized for Replit development environment
- **Hot Module Replacement**: Vite provides fast development experience
- **TypeScript Checking**: Real-time type checking during development

### Production Build
- **Frontend**: Vite builds optimized React bundle
- **Backend**: esbuild bundles Express server for Node.js
- **Static Assets**: Served through Express in production

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL
- **Authentication**: Replit Auth configuration
- **Session**: Secure session management with SESSION_SECRET

### Scalability Considerations
- **Database Connection Pooling**: Neon serverless handles connection scaling
- **Stateless Backend**: Session storage in database enables horizontal scaling
- **CDN Ready**: Static assets can be served from CDN in production