import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import Header from "@/components/layout/header";
import { Search, Users, Star, Filter } from "lucide-react";

export default function Discover() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: skills, isLoading: skillsLoading } = useQuery({
    queryKey: ["/api/discover/search", searchQuery],
    enabled: searchQuery.length > 0,
    retry: false,
  });

  const { data: matches, isLoading: matchesLoading } = useQuery({
    queryKey: ["/api/discover/matches"],
    retry: false,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Discover Skills</h1>
          <p className="text-gray-600">Find people with the skills you need and connect with them</p>
        </div>

        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="mr-2 h-5 w-5" />
              Search Skills
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search for skills like 'React', 'Python', 'Photography'..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
              </div>
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search Results */}
        {searchQuery && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Search Results for "{searchQuery}"</CardTitle>
            </CardHeader>
            <CardContent>
              {skillsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center space-x-4">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-48 mb-2" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                      <Skeleton className="h-8 w-24" />
                    </div>
                  ))}
                </div>
              ) : skills?.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Search className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                  <p>No skills found matching your search</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {skills?.map((skill: any) => (
                    <div key={skill.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center">
                        <Avatar className="h-12 w-12 mr-4">
                          <AvatarImage src="" alt="User" />
                          <AvatarFallback>U</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-medium">{skill.name}</h3>
                          <p className="text-sm text-gray-600">
                            {skill.level} • {skill.category}
                          </p>
                          <p className="text-xs text-gray-500">{skill.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={skill.type === 'offered' ? 'default' : 'secondary'}>
                          {skill.type}
                        </Badge>
                        <Button size="sm">Connect</Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Recommended Matches */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="mr-2 h-5 w-5 text-accent" />
              Recommended for You
            </CardTitle>
          </CardHeader>
          <CardContent>
            {matchesLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <div className="flex items-center mb-3">
                        <Skeleton className="h-12 w-12 rounded-full mr-3" />
                        <div>
                          <Skeleton className="h-4 w-24 mb-2" />
                          <Skeleton className="h-3 w-32" />
                        </div>
                      </div>
                      <Skeleton className="h-3 w-48 mb-2" />
                      <Skeleton className="h-3 w-40 mb-3" />
                      <div className="flex space-x-2">
                        <Skeleton className="h-8 w-24" />
                        <Skeleton className="h-8 w-16" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : matches?.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Users className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <p>No matches found</p>
                <p className="text-sm">Add some skills to find potential matches</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {matches?.map((match: any) => (
                  <Card key={match.id} className="card-hover">
                    <CardContent className="p-4">
                      <div className="flex items-center mb-3">
                        <Avatar className="h-12 w-12 mr-3">
                          <AvatarImage src={match.profileImageUrl} alt={match.firstName} className="object-cover" />
                          <AvatarFallback>
                            {match.firstName?.[0]}{match.lastName?.[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium text-gray-900">
                            {match.firstName} {match.lastName}
                          </h4>
                          <p className="text-sm text-gray-600">{match.title || "Skill Swapper"}</p>
                          <div className="flex items-center mt-1">
                            {Array.from({ length: 5 }, (_, i) => (
                              <Star key={i} className="h-3 w-3 text-yellow-400 fill-current" />
                            ))}
                            <span className="ml-1 text-xs text-gray-600">4.9</span>
                          </div>
                        </div>
                      </div>
                      <div className="mb-3">
                        <p className="text-sm text-gray-600">
                          <span className="text-green-500">→</span> Available for skill exchange
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" className="flex-1">
                          <Users className="mr-1 h-4 w-4" />
                          Request Swap
                        </Button>
                        <Button size="sm" variant="outline">
                          View
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
