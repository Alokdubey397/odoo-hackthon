import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import Header from "@/components/layout/header";
import { HandHeart, Clock, CheckCircle, XCircle, MessageSquare } from "lucide-react";

export default function Swaps() {
  const { data: swapRequests, isLoading } = useQuery({
    queryKey: ["/api/swaps"],
    retry: false,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "accepted":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "accepted":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      case "completed":
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const pendingSwaps = swapRequests?.filter((swap: any) => swap.status === "pending") || [];
  const activeSwaps = swapRequests?.filter((swap: any) => swap.status === "accepted") || [];
  const completedSwaps = swapRequests?.filter((swap: any) => swap.status === "completed") || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Swaps</h1>
          <p className="text-gray-600">Manage your skill exchange requests and track progress</p>
        </div>

        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending">
              Pending ({pendingSwaps.length})
            </TabsTrigger>
            <TabsTrigger value="active">
              Active ({activeSwaps.length})
            </TabsTrigger>
            <TabsTrigger value="completed">
              Completed ({completedSwaps.length})
            </TabsTrigger>
            <TabsTrigger value="all">
              All ({swapRequests?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="mr-2 h-5 w-5 text-yellow-500" />
                  Pending Requests
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Skeleton className="h-12 w-12 rounded-full" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-48 mb-2" />
                          <Skeleton className="h-3 w-32" />
                        </div>
                        <Skeleton className="h-8 w-20" />
                      </div>
                    ))}
                  </div>
                ) : pendingSwaps.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Clock className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No pending swap requests</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingSwaps.map((swap: any) => (
                      <div key={swap.id} className="flex items-center justify-between p-4 border rounded-lg card-hover">
                        <div className="flex items-center">
                          <Avatar className="h-12 w-12 mr-4">
                            <AvatarImage src="" alt="User" />
                            <AvatarFallback>U</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">Swap Request</h3>
                            <p className="text-sm text-gray-600">
                              Skill exchange request
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(swap.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(swap.status)}>
                            {getStatusIcon(swap.status)}
                            <span className="ml-1 capitalize">{swap.status}</span>
                          </Badge>
                          <Button size="sm" variant="outline">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <HandHeart className="mr-2 h-5 w-5 text-green-500" />
                  Active Swaps
                </CardTitle>
              </CardHeader>
              <CardContent>
                {activeSwaps.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <HandHeart className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No active swaps</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activeSwaps.map((swap: any) => (
                      <div key={swap.id} className="flex items-center justify-between p-4 border rounded-lg card-hover">
                        <div className="flex items-center">
                          <Avatar className="h-12 w-12 mr-4">
                            <AvatarImage src="" alt="User" />
                            <AvatarFallback>U</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">Active Swap</h3>
                            <p className="text-sm text-gray-600">
                              Skill exchange in progress
                            </p>
                            <p className="text-xs text-gray-500">
                              Started {new Date(swap.updatedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(swap.status)}>
                            {getStatusIcon(swap.status)}
                            <span className="ml-1 capitalize">{swap.status}</span>
                          </Badge>
                          <Button size="sm">Complete</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="mr-2 h-5 w-5 text-blue-500" />
                  Completed Swaps
                </CardTitle>
              </CardHeader>
              <CardContent>
                {completedSwaps.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <CheckCircle className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No completed swaps yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {completedSwaps.map((swap: any) => (
                      <div key={swap.id} className="flex items-center justify-between p-4 border rounded-lg card-hover">
                        <div className="flex items-center">
                          <Avatar className="h-12 w-12 mr-4">
                            <AvatarImage src="" alt="User" />
                            <AvatarFallback>U</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">Completed Swap</h3>
                            <p className="text-sm text-gray-600">
                              Skill exchange completed
                            </p>
                            <p className="text-xs text-gray-500">
                              Completed {new Date(swap.updatedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(swap.status)}>
                            {getStatusIcon(swap.status)}
                            <span className="ml-1 capitalize">{swap.status}</span>
                          </Badge>
                          <Button size="sm" variant="outline">
                            Review
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="all" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <HandHeart className="mr-2 h-5 w-5" />
                  All Swap Requests
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Skeleton className="h-12 w-12 rounded-full" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-48 mb-2" />
                          <Skeleton className="h-3 w-32" />
                        </div>
                        <Skeleton className="h-8 w-20" />
                      </div>
                    ))}
                  </div>
                ) : swapRequests?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <HandHeart className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No swap requests yet</p>
                    <p className="text-sm">Start by discovering skills and connecting with others</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {swapRequests?.map((swap: any) => (
                      <div key={swap.id} className="flex items-center justify-between p-4 border rounded-lg card-hover">
                        <div className="flex items-center">
                          <Avatar className="h-12 w-12 mr-4">
                            <AvatarImage src="" alt="User" />
                            <AvatarFallback>U</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">Swap Request</h3>
                            <p className="text-sm text-gray-600">
                              Skill exchange request
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(swap.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(swap.status)}>
                            {getStatusIcon(swap.status)}
                            <span className="ml-1 capitalize">{swap.status}</span>
                          </Badge>
                          <Button size="sm" variant="outline">
                            View
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
