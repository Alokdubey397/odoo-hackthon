import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Check, X, Clock, MessageSquare, ArrowRight, ArrowLeft } from "lucide-react";

interface SwapRequestCardProps {
  swap: {
    id: number;
    requesterId: string;
    recipientId: string;
    requesterSkillId?: number;
    recipientSkillId?: number;
    message?: string;
    status: string;
    createdAt: string;
    updatedAt: string;
  };
  currentUserId: string;
  onStatusChange?: () => void;
}

export default function SwapRequestCard({ swap, currentUserId, onStatusChange }: SwapRequestCardProps) {
  const { toast } = useToast();

  const updateStatusMutation = useMutation({
    mutationFn: async ({ status }: { status: string }) => {
      return await apiRequest("PUT", `/api/swaps/${swap.id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Swap request updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/swaps"] });
      queryClient.invalidateQueries({ queryKey: ["/api/swaps/pending"] });
      onStatusChange?.();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update swap request",
        variant: "destructive",
      });
    },
  });

  const handleAccept = () => {
    updateStatusMutation.mutate({ status: "accepted" });
  };

  const handleReject = () => {
    updateStatusMutation.mutate({ status: "rejected" });
  };

  const handleComplete = () => {
    updateStatusMutation.mutate({ status: "completed" });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "accepted":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "accepted":
        return <Check className="h-4 w-4" />;
      case "rejected":
        return <X className="h-4 w-4" />;
      case "completed":
        return <Check className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const isRecipient = swap.recipientId === currentUserId;
  const isRequester = swap.requesterId === currentUserId;
  const canAcceptOrReject = isRecipient && swap.status === "pending";
  const canComplete = (isRecipient || isRequester) && swap.status === "accepted";

  return (
    <Card className="card-hover transition-all duration-200 hover:shadow-lg">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Avatar className="h-12 w-12 mr-4">
              <AvatarImage src="" alt="User" />
              <AvatarFallback>
                {isRecipient ? "R" : "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="font-medium text-gray-900">
                {isRecipient ? "Incoming Swap Request" : "Outgoing Swap Request"}
              </h4>
              <p className="text-sm text-gray-600">
                {isRecipient ? "Someone wants to swap skills with you" : "Waiting for response"}
              </p>
              <div className="flex items-center mt-1 text-xs text-gray-500">
                <span>{new Date(swap.createdAt).toLocaleDateString()}</span>
                {swap.message && (
                  <>
                    <span className="mx-2">•</span>
                    <MessageSquare className="h-3 w-3 mr-1" />
                    <span>Has message</span>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Badge className={getStatusColor(swap.status)}>
              {getStatusIcon(swap.status)}
              <span className="ml-1 capitalize">{swap.status}</span>
            </Badge>
            
            {canAcceptOrReject && (
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  onClick={handleAccept}
                  disabled={updateStatusMutation.isPending}
                  className="bg-secondary hover:bg-secondary/90"
                >
                  <Check className="h-4 w-4 mr-1" />
                  Accept
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={handleReject}
                  disabled={updateStatusMutation.isPending}
                >
                  <X className="h-4 w-4 mr-1" />
                  Decline
                </Button>
              </div>
            )}
            
            {canComplete && (
              <Button
                size="sm"
                onClick={handleComplete}
                disabled={updateStatusMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Check className="h-4 w-4 mr-1" />
                Complete
              </Button>
            )}
            
            {!canAcceptOrReject && !canComplete && (
              <Button size="sm" variant="outline">
                <MessageSquare className="h-4 w-4 mr-1" />
                View Details
              </Button>
            )}
          </div>
        </div>
        
        {swap.message && (
          <div className="mt-3 p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-700">{swap.message}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
