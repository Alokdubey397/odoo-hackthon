import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit3, Trash2 } from "lucide-react";

interface SkillTagProps {
  skill: {
    id: number;
    name: string;
    level: string;
    type: "offered" | "wanted";
    category?: string;
    description?: string;
  };
  onEdit?: (skill: any) => void;
  onDelete?: (skillId: number) => void;
  showActions?: boolean;
}

export default function SkillTag({ skill, onEdit, onDelete, showActions = false }: SkillTagProps) {
  const getTagColor = (type: string) => {
    switch (type) {
      case "offered":
        return "bg-blue-50 text-primary hover:bg-blue-100";
      case "wanted":
        return "bg-green-50 text-secondary hover:bg-green-100";
      default:
        return "bg-gray-50 text-gray-700 hover:bg-gray-100";
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "text-green-600";
      case "intermediate":
        return "text-yellow-600";
      case "advanced":
        return "text-orange-600";
      case "expert":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };

  return (
    <div className="group relative">
      <Badge
        variant="secondary"
        className={`skill-tag ${getTagColor(skill.type)} cursor-pointer transition-all duration-200 hover:-translate-y-0.5 mr-2 mb-2`}
      >
        <span className="font-medium">{skill.name}</span>
        <span className={`ml-2 text-xs opacity-70 ${getLevelColor(skill.level)}`}>
          {skill.level}
        </span>
      </Badge>
      
      {showActions && (
        <div className="absolute top-0 right-0 -mt-1 -mr-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <div className="flex space-x-1">
            {onEdit && (
              <Button
                size="sm"
                variant="ghost"
                className="h-6 w-6 p-0 bg-white border border-gray-200 hover:bg-gray-50"
                onClick={() => onEdit(skill)}
              >
                <Edit3 className="h-3 w-3" />
              </Button>
            )}
            {onDelete && (
              <Button
                size="sm"
                variant="ghost"
                className="h-6 w-6 p-0 bg-white border border-gray-200 hover:bg-red-50 text-red-600"
                onClick={() => onDelete(skill.id)}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
