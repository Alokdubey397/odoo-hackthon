import {
  users,
  skills,
  swapRequests,
  reviews,
  type User,
  type UpsertUser,
  type Skill,
  type InsertSkill,
  type SwapRequest,
  type InsertSwapRequest,
  type Review,
  type InsertReview,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, asc, ne, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Skill operations
  getUserSkills(userId: string): Promise<Skill[]>;
  getSkillsByType(userId: string, type: "offered" | "wanted"): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  updateSkill(id: number, skill: Partial<InsertSkill>): Promise<Skill>;
  deleteSkill(id: number): Promise<void>;
  
  // Swap request operations
  getSwapRequests(userId: string): Promise<SwapRequest[]>;
  getPendingSwapRequests(userId: string): Promise<SwapRequest[]>;
  createSwapRequest(swapRequest: InsertSwapRequest): Promise<SwapRequest>;
  updateSwapRequestStatus(id: number, status: string): Promise<SwapRequest>;
  getSwapRequestById(id: number): Promise<SwapRequest | undefined>;
  
  // Review operations
  getUserReviews(userId: string): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  
  // Discovery operations
  findMatchingUsers(userId: string): Promise<User[]>;
  searchSkills(query: string): Promise<Skill[]>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  getAllSwapRequests(): Promise<SwapRequest[]>;
  updateUserAdminStatus(userId: string, isAdmin: boolean): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserSkills(userId: string): Promise<Skill[]> {
    return await db
      .select()
      .from(skills)
      .where(eq(skills.userId, userId))
      .orderBy(asc(skills.createdAt));
  }

  async getSkillsByType(userId: string, type: "offered" | "wanted"): Promise<Skill[]> {
    return await db
      .select()
      .from(skills)
      .where(and(eq(skills.userId, userId), eq(skills.type, type)))
      .orderBy(asc(skills.createdAt));
  }

  async createSkill(skill: InsertSkill): Promise<Skill> {
    const [newSkill] = await db
      .insert(skills)
      .values(skill)
      .returning();
    return newSkill;
  }

  async updateSkill(id: number, skill: Partial<InsertSkill>): Promise<Skill> {
    const [updatedSkill] = await db
      .update(skills)
      .set({ ...skill, updatedAt: new Date() })
      .where(eq(skills.id, id))
      .returning();
    return updatedSkill;
  }

  async deleteSkill(id: number): Promise<void> {
    await db.delete(skills).where(eq(skills.id, id));
  }

  async getSwapRequests(userId: string): Promise<SwapRequest[]> {
    return await db
      .select()
      .from(swapRequests)
      .where(or(eq(swapRequests.requesterId, userId), eq(swapRequests.recipientId, userId)))
      .orderBy(desc(swapRequests.createdAt));
  }

  async getPendingSwapRequests(userId: string): Promise<SwapRequest[]> {
    return await db
      .select()
      .from(swapRequests)
      .where(
        and(
          eq(swapRequests.recipientId, userId),
          eq(swapRequests.status, "pending")
        )
      )
      .orderBy(desc(swapRequests.createdAt));
  }

  async createSwapRequest(swapRequest: InsertSwapRequest): Promise<SwapRequest> {
    const [newSwapRequest] = await db
      .insert(swapRequests)
      .values(swapRequest)
      .returning();
    return newSwapRequest;
  }

  async updateSwapRequestStatus(id: number, status: string): Promise<SwapRequest> {
    const [updatedSwapRequest] = await db
      .update(swapRequests)
      .set({ status, updatedAt: new Date() })
      .where(eq(swapRequests.id, id))
      .returning();
    return updatedSwapRequest;
  }

  async getSwapRequestById(id: number): Promise<SwapRequest | undefined> {
    const [swapRequest] = await db
      .select()
      .from(swapRequests)
      .where(eq(swapRequests.id, id));
    return swapRequest;
  }

  async getUserReviews(userId: string): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.revieweeId, userId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db
      .insert(reviews)
      .values(review)
      .returning();
    return newReview;
  }

  async findMatchingUsers(userId: string): Promise<User[]> {
    // Find users who offer skills that the current user wants
    const userWantedSkills = await db
      .select()
      .from(skills)
      .where(and(eq(skills.userId, userId), eq(skills.type, "wanted")));

    if (userWantedSkills.length === 0) {
      return [];
    }

    const wantedSkillNames = userWantedSkills.map(skill => skill.name);

    // Use multiple OR conditions instead of inArray for better compatibility
    const skillConditions = wantedSkillNames.map(skillName => eq(skills.name, skillName));
    const skillMatch = skillConditions.length === 1 
      ? skillConditions[0] 
      : or(...skillConditions);

    const results = await db
      .select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
        bio: users.bio,
        title: users.title,
        location: users.location,
        isAdmin: users.isAdmin,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
      })
      .from(users)
      .innerJoin(skills, eq(skills.userId, users.id))
      .where(
        and(
          ne(users.id, userId),
          eq(skills.type, "offered"),
          skillMatch
        )
      )
      .limit(10);

    return results;
  }

  async searchSkills(query: string): Promise<Skill[]> {
    return await db
      .select()
      .from(skills)
      .where(sql`${skills.name} ILIKE ${`%${query}%`}`)
      .orderBy(asc(skills.name));
  }

  async getAllUsers(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt));
  }

  async getAllSwapRequests(): Promise<SwapRequest[]> {
    return await db
      .select()
      .from(swapRequests)
      .orderBy(desc(swapRequests.createdAt));
  }

  async updateUserAdminStatus(userId: string, isAdmin: boolean): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ isAdmin, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }
}

export const storage = new DatabaseStorage();
