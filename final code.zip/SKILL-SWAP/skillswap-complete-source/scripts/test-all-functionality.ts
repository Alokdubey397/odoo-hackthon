import { db } from "../server/db";
import { storage } from "../server/storage";
import { users, skills, swapRequests } from "../shared/schema";

async function testAllFunctionality() {
  console.log("🧪 Testing SkillSwap Platform Functionality");
  console.log("=" .repeat(50));

  let testsPassed = 0;
  let testsTotal = 0;

  function test(description: string, fn: () => Promise<void>) {
    return async () => {
      testsTotal++;
      try {
        await fn();
        console.log(`✅ ${description}`);
        testsPassed++;
      } catch (error) {
        console.log(`❌ ${description}`);
        console.log(`   Error: ${error.message}`);
      }
    };
  }

  // Test 1: Database connection
  await test("Database connection", async () => {
    const result = await db.select().from(users).limit(1);
    if (result.length === 0) throw new Error("No users found");
  })();

  // Test 2: User operations
  await test("User operations", async () => {
    const user = await storage.getUser("42460279");
    if (!user) throw new Error("User not found");
    if (!user.firstName) throw new Error("User data incomplete");
  })();

  // Test 3: Skill operations
  await test("Skill operations", async () => {
    const skills = await storage.getUserSkills("42460279");
    if (skills.length === 0) throw new Error("No skills found for user");
  })();

  // Test 4: Skill matching
  await test("Skill matching algorithm", async () => {
    const matches = await storage.findMatchingUsers("42460279");
    // Should not throw error, even if no matches found
    console.log(`   Found ${matches.length} matches`);
  })();

  // Test 5: Swap request operations
  await test("Swap request operations", async () => {
    const swaps = await storage.getSwapRequests("42460279");
    // Should not throw error, even if no swaps found
    console.log(`   Found ${swaps.length} swap requests`);
  })();

  // Test 6: Search functionality
  await test("Search functionality", async () => {
    const results = await storage.searchSkills("JavaScript");
    console.log(`   Found ${results.length} skills matching 'JavaScript'`);
  })();

  // Test 7: Admin operations
  await test("Admin operations", async () => {
    const allUsers = await storage.getAllUsers();
    if (allUsers.length === 0) throw new Error("No users found");
    console.log(`   Found ${allUsers.length} total users`);
  })();

  // Test 8: Sample data verification
  await test("Sample data verification", async () => {
    const indianUsers = await db.select().from(users).where(
      sql`location LIKE '%India%' OR location LIKE '%Mumbai%' OR location LIKE '%Delhi%' OR location LIKE '%Bangalore%'`
    );
    console.log(`   Found ${indianUsers.length} Indian users`);
  })();

  // Test 9: Skill categories
  await test("Skill categories", async () => {
    const categories = await db.select({ category: skills.category }).from(skills).groupBy(skills.category);
    console.log(`   Found ${categories.length} skill categories`);
  })();

  // Test 10: Data integrity
  await test("Data integrity", async () => {
    const userCount = await db.select().from(users);
    const skillCount = await db.select().from(skills);
    const swapCount = await db.select().from(swapRequests);
    
    console.log(`   Users: ${userCount.length}`);
    console.log(`   Skills: ${skillCount.length}`);
    console.log(`   Swap Requests: ${swapCount.length}`);
    
    if (userCount.length === 0) throw new Error("No users in database");
    if (skillCount.length === 0) throw new Error("No skills in database");
  })();

  console.log("\n" + "=" .repeat(50));
  console.log(`🏁 Testing Complete: ${testsPassed}/${testsTotal} tests passed`);
  
  if (testsPassed === testsTotal) {
    console.log("🎉 All tests passed! Platform is working correctly.");
    return true;
  } else {
    console.log("⚠️  Some tests failed. Check the errors above.");
    return false;
  }
}

// Run the tests
if (import.meta.url === `file://${process.argv[1]}`) {
  testAllFunctionality()
    .then((success) => {
      process.exit(success ? 0 : 1);
    })
    .catch((error) => {
      console.error("💥 Test execution failed:", error);
      process.exit(1);
    });
}

export { testAllFunctionality };